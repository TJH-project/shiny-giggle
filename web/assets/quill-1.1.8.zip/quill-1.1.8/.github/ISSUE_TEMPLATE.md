[Describe the issue]

**Steps for Reproduction**

1. Visit [quilljs.com, jsfiddle.net, codepen.io]
2. Step Two
3. Step Three

**Expected behavior**:

**Actual behavior**:

**Platforms**:

Include browser, operating system and respective versions

**Version**:

Run `Quill.version` to find out
