import Parchment from 'parchment';

class Embed extends Parchment.Embed { }

export default Embed;
